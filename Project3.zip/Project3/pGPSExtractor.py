import os 
import _modEXIF 
import csvHandler 
import commandParser
from class_logging import _ForensicLog

#offsets into the return EXIFData for 
#timeStamp, Camera make, and model 

TS = 0 
MAKE = 1 
MODEL = 2

#process the command line args

userArgs = commandParser.ParseCommandLine()

#create a log object 
logPath = userArgs.logPath + "ForensicLog.txt"
oLog = _ForensicLog(logPath)

oLog.writeLog("INFO", "Scan Started")

csvPath = userArgs.csvPath + "imageResults.csv" 
oCSV = csvHandler._CSVWriter(csvPath)

#define a directory to scan 
scanDir = userArgs.scanPath

print userArgs.scanPath

try: 
    picts = os.listdir(scanDir)
except:
    oLog.writeLog("Error", "Invalid Directory" + scanDir)
    exit(0)

print "Program start" 
print 

for aFile in picts: 

    targetFile = scanDir + "/" + aFile
    #targetFile = aFile
    
    if os.path.isfile(targetFile):
       
        gpsDictionary, EXIFList = _modEXIF.ExtractGPSDictionary(targetFile)

        if(gpsDictionary): 

            #obtain the lAT LON values from the gpsDictionary 
            #covered to degrees 
            #retrun values in a dictionary key values pairs 
           
            dCoor = _modEXIF.ExtractLatLon(gpsDictionary)
        
            lat = dCoor.get("Lat")
            latRef = dCoor.get("LatRef") 
            lon = dCoor.get("Lon") 
            lonRef = dCoor.get("LonRef")
            alt = dCoor.get("alt", None)
            altRef = dCoor.get("altRef", None)
    
            if(lat and lon and latRef and lonRef or alt or altRef):
                   
                print str(lat) + ', ' + str(lon) + ', ' + str(alt)
            
                #write one row to the output file 
                oCSV.writeCSVRow(targetFile, EXIFList[TS], EXIFList [MAKE], EXIFList[MODEL]
                ,latRef, lat, lonRef, lon, altRef, alt)

                oLog.writeLog("INFO", "GPS data Calculated for: " + targetFile)
            else: 
                oLog.writeLog("WARNING", "No GPS EXIF data for " + targetFile)

        else: 
            oLog.writeLog("WARNING", "No GPS EXIF data for " + targetFile)

    else: 
        oLog.writeLog("WARNING", targetFile + " not a valid file")

#Clean up and close log and csv file 
del oLog
del oCSV
