#!/usr/bin/python2.7

import csv 
import sys 

class _CSVWriter:

    def __init__(self, fileName):
        try:
    # create a writer object and then write the header row 
            self.csvFile = open(fileName,'wb')
            self.writer = csv.writer(self.csvFile, delimiter = ',', quoting = csv.QUOTE_ALL)
            self.writer.writerow( ('Image Path','Make','Model','UTC Time', 'Lat Ref',
            'Latitude','Lon Ref','Longitude', 'Alt Ref', 'Altitude') ) 
        except:
            log.error('CSV File Failure')
    def writeCSVRow(self, fileName, cameraMake, cameraModel, utc, latRef,
                    latValue, lonRef, lonValue, altRef, altValue):

        latStr = '%.8f'% latValue
        lonStr = '%.8f'% lonValue
        altStr = '%.2f'% altValue + ' Meters'


        self.writer.writerow((fileName, cameraMake, cameraModel, utc,
        latRef, latStr, lonRef, lonStr, altRef, altStr))

    def __del__(self): 
        self.csvFile.close()