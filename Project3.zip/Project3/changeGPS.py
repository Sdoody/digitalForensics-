#!/usr/bin/python2.7
import piexif
import sys
import shutil 
import random

# gets the system args for the program to run 
origFile = sys.argv[1]
fakeFile = sys.argv[2]

#Makes random numbers and letters for Lat and Long
lonRef= 'W', 'E'
latRef = 'N', 'S'

latDegr = random.randint(1,90)
latMins = random.randint(1,59)
latSec = random.randint(1, 59)
lonDegr = random.randint(1, 180)
lonMins = random.randint(1,59)
lonSec = random.randint(1, 59)
lonDirection = random.choice(lonRef)
latDirection = random.choice(latRef)
year = random.randint(1990, 2018)
month = random.randint(1,12)
day = random.randint(1,30)
hour = random.randint(0,23)
minute = random.randint(0,60)
second = random.randint(0,60)


yearDayMonth = str(year) + ':' + str(month) + ':' +str(day) 
hoursMinsSecond = str(hour) + ':' +  str(minute) + ':' + str(second)

print yearDayMonth
print hoursMinsSecond



#copys the files 
shutil.copy(origFile, fakeFile)

# loads the exif data for the origal image 
exifData = piexif.load(origFile)


print 
print "OLD GPS "
print "==========================================="
print exifData['GPS']
print 

# false GPS info that we are trying to dump and insert into the image. 
newDict = { 1: latDirection, 2: ((latDegr,1 ), (latMins, 1)  ,(latSec, 1)),
            3: lonDirection, 4: ((lonDegr,1 ), (lonMins, 1)  ,(lonSec, 1))}

newTime = {36867: (yearDayMonth + " " + hoursMinsSecond)}


#overwrites the GPS data from the original file and puts the false info in there. 
exifData["GPS"] = newDict
#exifData['Exif'][36867] = newTime


# dumps the byes from the orignal image 
dump = piexif.dump(exifData)


#inserts those bytes to the fake image 
insert = piexif.insert(dump,fakeFile)

print
print "NEW GPS"
print "==========================================="
# prints out the fake images EXIF data 
newCat = piexif.load(fakeFile)

print newCat['GPS']
print 
#print newCat['Exif']
#print newCat['Exif']['36864']
