import argparse
import os 

def ParseCommandLine(): 

    parser = argparse.ArgumentParser('Python gpsExtractor')

    parser.add_argument('-v', '--verbose',help="Enables additional program messages",
     action = 'store_true')

    parser.add_argument('-l', '--logPath', type=ValidateDirectory, 
     required = True, help="Specify output of log file")

    parser.add_argument('-c', '--csvPath', type=ValidateDirectory, 
     required = True, help = "Specify ouput for csv file")

    parser.add_argument('-d', '--scanPath', type = ValidateDirectory,
     required = True, help = "Specify directory to scan")

    theArgs = parser.parse_args()

    return theArgs

#end Parse ComandLine ======================================

def ValidateDirectory(theDir):

    #validate the path is a directory 
    if not os.path.isdir(theDir):
        raise argparse.ArgumentTypeError('Directory does not exist')

    #Validate the path is writable 

    if os.access(theDir, os.W_OK):
        return theDir
    else: 
        raise argparse.ArgumentTypeError('Directory is not writable')

#end validatedirectoy 

