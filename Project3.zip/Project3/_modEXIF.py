import os 
from class_logging import _ForensicLog
from PIL import Image 
from PIL.ExifTags import TAGS, GPSTAGS


def ExtractGPSDictionary(fileName): 

    try: 
        pilImage = Image.open(fileName)
        EXIFData = pilImage._getexif()
        #print EXIFData['GPSInfo']

    except Exception:
        #if exception occurs from PIL processing 
        #report the 
        return None, None 

    #Iterate through the EXIFdata 
    #Searching for GPS tags 

    imageTimeStamp = "NA"
    cameraModel = "NA"
    cameraMake = "NA"

    if EXIFData: 

        gpsDictionary = {}
        #print gpsDictionary
        #iterate through the exif data 
        for tag, value in EXIFData.items(): 
    
            #looks up english name for tags 
            tagName = TAGS.get(tag,tag)
            
           # print tagName
            if tagName == "DateTimeOriginal": 
                imageTimeStamp = value
            if tagName == "Make":
                cameraMake = value
            if tagName == "Model": 
                cameraModel = value 
            if tagName == "GPSInfo": 
                for gpsTag in value:
                    gpsTagName = GPSTAGS.get(gpsTag, gpsTag) 
                    gpsDictionary[gpsTagName] = value[gpsTag]
            
        basicEXIFData = [imageTimeStamp, cameraMake, cameraModel]
        return gpsDictionary, basicEXIFData
    
    else:
        #print "oops, returning None"
        return None,None

#end GPSDictinary==============================================

def ExtractLatLon(gps): 
    #to perform the calculation we need atleast 
    #lat, lon, latRef and lonRef 


    if (gps.has_key("GPSLatitude") and gps.has_key("GPSLongitude")
    and gps.has_key("GPSLatitudeRef") and gps.has_key("GPSLatitudeRef")):
    
        latitude = gps["GPSLatitude"]
        latitudeRef = gps["GPSLatitudeRef"]
        longitude = gps["GPSLongitude"]
        longitudeRef = gps["GPSLongitudeRef"]

        if gps.has_key("GPSAltitude") and gps.has_key("GPSAltitudeRef"):
            Altitude = gps["GPSAltitude"]
            AltitudeRef = gps["GPSAltitudeRef"]
            alt = float(Altitude[0] / Altitude[1])
            

        else: 
            Altitude = ""
            AltitudeRef = ""
            alt = 0.0
        lat = ConvertToDegrees(latitude)
        lon = ConvertToDegrees(longitude)

    
        #check latidtude Ref

        if latitudeRef == "S":
            lat = 0 - lat 
        #check longitude ref
        #if west of the prime meridian in 
        #greenwhich then the log value is negative 

        if longitudeRef == "W": 
            lon = 0 - lon

        gpsCoor = {"Lat": lat, "LatRef": latitudeRef, "Lon": lon, "LonRef": longitudeRef,
                    "alt": alt, "altRef": AltitudeRef}

        return gpsCoor

    else: 
        return None 

#End extract lat Lon ==============================================

def ConvertToDegrees(gpsCoordinate): 

    d0 = gpsCoordinate[0][0]
    d1 = gpsCoordinate[0][1] 
  

    try: 
        degrees = float(d0)/float(d1)
       # print degrees
    except:
        
        degrees = 0.0


    m0 = gpsCoordinate[1][0]
    m1 = gpsCoordinate[1][1] 
    try: 
        minutes = float(m0)/float(m1)
    except:
        minutes = 0.0


    s0 = gpsCoordinate[2][0]
    s1 = gpsCoordinate[2][1] 

    try: 
        seconds = float(s0)/float(s1)
    except:
        seconds = 0.0

    floatCoordinate = float(degrees + (minutes/60.0) + (seconds /3600.0))
    return floatCoordinate
                   