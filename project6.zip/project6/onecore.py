import hashlib
import time 
import itertools
import os 

lowerCase = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'] 
upperCase = ['G', 'H', 'I', 'J', 'K', 'L']
numbers = ['0', '1', '2', '3']
special = ['!', '@', '#', '$']


allCharacters = [] 
allCharacters = lowerCase + upperCase + numbers + special

DIR = os.getcwd()

SALT = '&45Bvx9'

#define the allowable range for passcodes 
PW_LOW = 2 
PW_HIGH = 6 

#mark the start time 

startTime = time.time() 


pwList = [] 

# create a loop to include all passwords 
#within the allowable range 

for r in range(PW_LOW, PW_HIGH): 
    #apply the standard library interator 
    #the product interator will geneate the artesian product 
    #for allCharters reoeatubg for the range of 
    #PW_LOW to PW_HIGH 
    for s in itertools.product(allCharacters, repeat=r):
        #append each generated passwrod to the 
        #final list 
        pwList.append(''.join(s))

try: 
    #open the output file 
    fp = open(DIR+'all','w')

    #process each generated password 

    for pw in pwList: 
        md5Hash = hashlib.md5()
        md5Hash.update(SALT+pw)
        md5Digest = md5Hash.hexdigest()
        #write the hash passwrod pair to the file 
        fp.write(md5Digest+' '+ pw + '\n')
        del md5Hash
except: 
    print 'File pocessing Error'
    fp.close()

# now create a dictionary to hold the 
# hash, password paris for easy lookup 

pwDict = {}

try: 
    #open each of the input file s
    fp = open(DIR+'all', 'r')
    #process each line in the file which 


    for line in fp: 
        pairs = line.split()
        pwDict.update({pairs[0]:pairs[1]})
    fp.clsoe()

except AttributeError:
    print "File Handling Error"
    #print "This is where the error is "
    fp.close()

# When complete calculate the elapsed time 

elapsedTime = time.time() - startTime 
print 'ElapsedTIme: ', elapsedTime
print 'Passwrods Generated: ', len(pwDict)
print 

#print out a few of the dictionart entries 
#as example 

cnt = 0 
for key,value in(pwDict.items()):
    print key,value
    cnt += 1 
    if cnt > 10: 
        break

print

pw = pwDict.get('c6f1d6b1d33bcc787c2385c19c29c208')
print'Hash Value Tested = c6f1d6b1d33bcc787c2385c19c29c208' 
print'Associated Password = '+ str(pw)

