import os 
import sys

filename = sys.argv[1]

try: 
    openShadow = open(filename, 'r')

except IOError: 
    print "File not found " 


try: 
    openRainbow = open('passwords.txt', 'r') 

except NameError, IOError:
    print " File not found"

shadow = []
rainbow = {}

for aline in openShadow: 
    shadowinfo = aline.rstrip('\n').split(':')
    shadow.append(shadowinfo)
    

for line in openRainbow: 
    rainbow = line.rstrip('\n').split(' ')

    for i in shadow:
        if rainbow[0] == i[1]:
            rainbow[0] = rainbow[1]
            print 
            print "The username/password is: " +  i[0] + '/' + rainbow[1]
print 
print "Closing open files...Goodbye"
print 


openShadow.close() 
openRainbow.close()