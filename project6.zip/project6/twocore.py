import hashlib
import time 
import itertools
import os 
import multiprocessing


lowerCase = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'] 
upperCase = ['G', 'H', 'I', 'J', 'K', 'L']
numbers = ['0', '1', '2', '3']
special = ['!', '@', '#', '$']



allCharacters = [] 
allCharacters = lowerCase + upperCase + numbers + special

DIR = os.getcwd()

SALT = '&45Bvx9'

#define the allowable range for passcodes 
PW_LOW = 2 
PW_HIGH = 6 


def pwGenerator(size): 

    pwList = []

    for r in range(size, size+1): 

        for s in itertools.product(allCharacters, repeat=r): 
        # apply the standard library interator 
        #final list 
            pwList.append(''.join(s))

    # for each password in the list generate 
    # an associate md5 hash and utilize the 
    # hash as the key 


    #try: 
        # open the output file 

    fp = open(DIR+str(size), 'w')

    for pw in pwList: 
            # perform hashing of the password 
        md5Hash = hashlib.md5()
        md5Hash.update(SALT+pw)
        md5Digest = md5Hash.hexdigest()
            # write the hash psaswrod pair to the file 
        fp.write(md5Digest + ' ' + pw + '\n')
        del md5Hash

    #except: 
        #print 'File proccessing Error'

    #finally: 
        #fp.close()



# create the main function 

if __name__== '__main__': 

    # mark the starting time of the main loop 

    startTime = time.time() 

    #create a process poll with 2 processes 

    corePool = multiprocessing.Pool(processes=2)
    print corePool

    # map corePool to the Pool processes 
    results = corePool.map(pwGenerator,(2,3, 4, 5))
    
    # create a dictionary for easy lookups 
    pwDict = {}


    for i in range(PW_LOW, PW_HIGH): 
        #try:
            #open  each of the outputs files 
        fp = open(DIR+str(i), 'r')
            #process each line in the file which 
            # contains keym value pairs 
        for line in fp: 
                #extract the key value pairs 
                # and update the dictionary 
            pairs = line.split()
            pwDict.update({pairs[0]:pairs[1]})

        fp.close()
        #except:
            #print 'File handling Error'
        fp.close() 

    elapsedTime = time.time() - startTime
    print 'Elapsed Time: ', elapsedTime, 'Seconds'


    print 'Passwords Generated: ', len(pwDict)
    print 
    cnt = 0
    for key,value in (pwDict.items()):
        print key,value
        cnt += 1 
        if cnt > 10: 
            break

    pw = pwDict.get('c6f1d6b1d33bcc787c2385c19c29c208')
    print 'Hash Value Tested = \2bca9b23eb8419728fdeca3345b344fc'
    print 'Associated Password = ' + str(pw)