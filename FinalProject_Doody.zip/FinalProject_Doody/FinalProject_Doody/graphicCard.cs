﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace FinalProject_Doody
{
    class graphicCard
    {
        private string name, vRam, chipSet, ID;


        private string price;
        private string Picture;
        private string highEnd;

       
        public graphicCard()
        {


        }

        public graphicCard(string n, string vr, string ch, string pr, string ph, string hi, string id)
        {
            name = n;
            vRam = vr;
            chipSet = ch;
            price = pr;
            Picture = ph; 
            highEnd = hi;
            ID = id;
        }


        public string Name
        {
            get { return name; }
            set { name = value; }
        } 
        
        
        public string VRam
        {
            get { return vRam; }
            set { vRam = value; }
        }


        public string ChipSet
        {
            get { return chipSet; }
            set { chipSet = value; }
        }


        public string Price
        {
            get { return price; }
            set { price = value; }
        }

        public string picture
        {
           get { return Picture; }
           set { Picture = value; }
        }

        public string HighEnd
        {
            get { return highEnd; }
            set { highEnd = value; }
        }

        public string Id
        {
            get { return ID; }
            set { ID = value; }
        }

    }

       
}
