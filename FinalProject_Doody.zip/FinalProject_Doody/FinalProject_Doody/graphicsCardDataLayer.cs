﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;
using System.Drawing;

namespace FinalProject_Doody
{
    class graphicsCardDataLayer
    {
        private OleDbConnection conn;
        private OleDbCommand comm;
        private OleDbDataReader GpuReader; 

        public graphicsCardDataLayer()
        {
            string connString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=GraphicsCards.accdb";
            conn = new OleDbConnection(connString);
            conn.Open(); 
          
        }

        public List<graphicCard> getGrapicsCardsFromDatabase()
        {
            List<graphicCard> allGPU = new List<graphicCard>();

            string selectGraphicsCard = "SELECT * FROM GPU";
            try
            {
                comm = new OleDbCommand(selectGraphicsCard, conn);

                GpuReader = comm.ExecuteReader(CommandBehavior.CloseConnection);

                while (GpuReader.Read())
                {
                    string name = GpuReader["Name"].ToString();
                    string vRam = GpuReader["Vram"].ToString();
                    string chipset = GpuReader["Chipset"].ToString();
                    string price = GpuReader["Price"].ToString();
                    string high_end = GpuReader["High End"].ToString();
                    string ID = GpuReader["id"].ToString();
                    string photo = GpuReader["Picture"].ToString();


                    graphicCard g = new graphicCard(name, vRam, chipset, price, photo, high_end, ID);
                    allGPU.Add(g);
                } // end while 
            }
            catch(OleDbException)
            {
                System.Windows.Forms.MessageBox.Show("An error ocurred");
            }
            GpuReader.Close();

            return allGPU;

        }// end getGPU method 

        public void deleteGraphicsCardFromDatabase(graphicCard g)
        {
            conn.Open();

            string deleteGraphicsCard = "DELETE FROM GPU WHERE ID=? ";

            comm = new OleDbCommand(deleteGraphicsCard, conn);

            OleDbParameter paramID = new OleDbParameter("ID", g.Id);

            comm.Parameters.Add(paramID);

            comm.ExecuteNonQuery();

            conn.Close();
                   
        } // end delete method 


        public void addNewGPUToDataBase(graphicCard g)
        {
            conn.Open(); 
             
            string insertGPU = "INSERT INTO GPU ( Name, VRAM, Chipset, Price, Picture, [High End]) VALUES ( ?, ?, ?,?, ?, ?)";
            comm = new OleDbCommand(insertGPU, conn);

            OleDbParameter NameParam = new OleDbParameter("Name", g.Name);
            OleDbParameter VRAMParam = new OleDbParameter("VRam", g.VRam);
            OleDbParameter ChipsetParam = new OleDbParameter("Chipset", g.ChipSet);
            OleDbParameter PriceParam = new OleDbParameter("Price", g.Price);
            OleDbParameter PictureParam = new OleDbParameter("Picture", g.picture);
            OleDbParameter High_EndParam = new OleDbParameter("High End", g.HighEnd);
            

            comm.Parameters.Add(NameParam);
            comm.Parameters.Add(VRAMParam);
            comm.Parameters.Add(ChipsetParam);  
            comm.Parameters.Add(PriceParam);
            comm.Parameters.Add(PictureParam);
            comm.Parameters.Add(High_EndParam);
          

            comm.ExecuteNonQuery();
                   
        }
            

    }
}
