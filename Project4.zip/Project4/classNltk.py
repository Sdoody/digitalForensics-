#!/usr/bin/python2.7

import os 
import sys 
import logging 
import nltk 
from collections import Counter
from urllib import urlopen
from nltk.corpus import PlaintextCorpusReader
from nltk.corpus import stopwords
from nltk.stem.porter import *

stemmer = PorterStemmer()

#url = 'https://www.gutenberg.org/files/2760/2760-0.txt'
#rawText = urlopen(url).read().decode('UTF-8')

class classNLTKQuery: 

    def textCorpusInit(self, thePath): 
        #validate the directory 
        if not os.path.isdir(thePath):

            return "path is not a Directory"
        #validate the path is readable 
        if not os.access(thePath, os.R_OK): 
            return "Directory is not readable"

        try: 
            self.Corpus = PlaintextCorpusReader(thePath, '.*')
            print "Processing Files: "
            print self.Corpus.fileids()
            print "Please Wait..."
            self.rawText = self.Corpus.raw()
            self.tokens = nltk.word_tokenize(self.rawText)
            self.stopWords = nltk.word_tokenize(self.rawText)
            self.tokens = [ t.lower() for t in self.tokens]

            #makes a list of all the stops words in the corpus 
            #this is code that I added 
            self.noStop = [word.lower() for word in stopwords.words('english')]
            self.tokens_noStop = [t for t in self.stopWords if t not in self.noStop]
            self.text_noStop = nltk.Text(self.tokens_noStop)
            self.stemmedTokens = [stemmer.stem(t.lower()) for t in self.text_noStop]
            self.stemmedText = nltk.Text(self.stemmedTokens)

            #print self.stemmedText[100:500]

            #print self.tokens_noStop

            self.textCorpus = nltk.Text(self.tokens)
        
        except IOError: 

            return "Corpus Creation Failed"
        
        self.ActiveTextCorpus = True

        return "Success"

    def printCorpusLength(self): 
        print "Corpus Text Length: ", 
        print len(self.tokens)

    def printTokensFound(self):
        print "Tokens Found: ",
        print len(self.tokens)

    def printVocabSize(self):
        print "Calculating..."
        print "Vocabulary Size: ",
        VocabularyUsed = set(self.textCorpus)
        VocabularySize = len(VocabularyUsed)
        print VocabularySize

    def printSortedVocab(self): 
        print "Compiling..."
        print "Sorted Vocabulary"
        print sorted(set(self.textCorpus))

    def printCollocation(self):
        print "Compiling Collocations..."
        self.textCorpus.collocations()
    
    def searchWordOccurence(self): 
        myWord = raw_input("Enter Search Word: ")
        if myWord: 
            wordCount = self.textCorpus.count(myWord)
            print myWord + " occured: ", 
            print wordCount,
            print "times"
        else: 
            print "Word Entry is Invalid"

    def generateConcordance(self):
        myWord = raw_input("Enter word to Concord: ")
        if myWord: 
            self.textCorpus.concordance(myWord)

        else: 
            print "Word Entry is Invalid"
    
    def generateSimiliarities(self): 
        myWord = raw_input("Enter seed word: ")
        if myWord: 
            self.textCorpus.similar(myWord)
        else: 
            print "Word Entry is Invalid"

    def printWordIndex(self): 
        myWord = raw_input("Find first occurrence of what word?: ")
        if myWord: 
            try:
                wordIndex = self.textCorpus.index(myWord)
                print "First occurrence of: " + myWord + " is at offset: ", 
                print wordIndex

            except ValueError: 
                print "Word you typed is not in corpus!"

        else: 
            print "Word entry is invalid"


    def printVocabulary(self):
        print "Compiling Vocabulary Frequencies",
        vocabFreqList = self.textCorpus.vocab()
        print vocabFreqList.items()

    def stemmed(self):

        myWord = raw_input("Enter Search Word: ")
        myWord = myWord.upper()
        if myWord:
            stemming = stemmer.stem(myWord)
            wordCount = self.text_noStop.count(myWord)
            print stemming + " occured: ", 
            print wordCount,
            print "times"
        else: 
            print "Word Entry is Invalid"


    def posTag(self): 

        tagType = raw_input("Please enter the POS tag: ")

        tagged = nltk.pos_tag(self.textCorpus)
        pos = set() 
        for word, tag in tagged: 
            if tag.startswith(tagType):
                pos.add(word)

    def showTag(self): 

        myWord = raw_input("Please enter a word: ")

        tags = {} 
        tagged = nltk.pos_tag(self.textCorpus)
        for word, tag in tagged: 
            if word == myWord: 
                if tags.has_key(tag):
                    tags[tag] = tags[tag] + 1  
                else: 
                    tags[tag] = 1
        print tags

    def commonWordsWithTag(self):

        tagType = raw_input("Please enter the POS tag: ")
        
        tagged = self.text_noStop


        wordCount = Counter(word for tag in tagged
                        for word in tag.split())

        print(wordCount.most_common(45))



    
              
        