#!/usr/bin/python2.7

import sys 
import printMenu 

print "Welcome to the NLTK Query Experimentation"
print "Please wait loading NLTK..."

import classNltk

oNLTK = classNltk.classNLTKQuery()

print 
print 'Input full path name where intended corpus filer or files are stored'
print 'Note: You must enter a quoted string e.g ./simpson'
print 

userSpecifiedPath = raw_input("Path: ")

#print "This is running"

#attempt to create a text corpus 
result = oNLTK.textCorpusInit(userSpecifiedPath)

print result

if result == "Success": 
    menuSelection = -1

    while menuSelection != 0: 

        if menuSelection != -1: 
            print 

            s = raw_input('Press Enter to Continue...')

        menuSelection = printMenu.getUserSelection()

        if menuSelection == 1: 
            oNLTK.printCorpusLength()

        elif menuSelection == 2: 
            oNLTK.printTokensFound() 

        elif menuSelection == 3: 
            oNLTK.printVocabSize()

        elif menuSelection == 4: 
            oNLTK.printSortedVocab()

        elif menuSelection == 5: 
            oNLTK.printCollocation()

        elif menuSelection == 6: 
            oNLTK.searchWordOccurence()

        elif menuSelection == 7: 
            oNLTK.generateConcordance()
            
        elif menuSelection == 8: 
            oNLTK.generateSimiliarities()
            
        elif menuSelection == 9: 
            oNLTK.printWordIndex()

        elif menuSelection == 10: 
            oNLTK.printSortedVocab()  

        elif menuSelection == 11:
            oNLTK.stemmed()

        elif menuSelection == 12: 
            oNLTK.posTag()

        elif menuSelection == 13: 
            oNLTK.showTag()

        elif menuSelection == 14: 
            oNLTK.commonWordsWithTag() 
            

        elif menuSelection == 0: 
            continue
        else: 

            print "unexpected error condition"
    else: 
        print "Closing NLTK Query Experimentation"
