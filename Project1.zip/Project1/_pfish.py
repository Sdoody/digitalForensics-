#!/usr/bin/python

import os #Python Standard Library - Miscellaneous operating system interfaces
import stat #Python Standard Library - functions for interpreting os results
import time #Python Standard Library - Time access and conversions functions
import hashlib #Python Standard Library - Secure hashes and message digests
import argparse #Python Standard Library - Parser for command- line options, arguments
import csv #Python Standard Library - reader and writer for csv files
import logging #Python Standard Library -logging facility

log = logging.getLogger('main._pfish')

# Name: ParseCommand() Function #
# Desc: Process and Validate the command line arguments
# use Python Standard Library module argparse #
# Input: none #
# Actions: #
#Uses the standard library argparse to process the command line
#establishes a global variable gl_args where any of the functions can

def ParseCommandLine():

    parser = argparse.ArgumentParser('Python file system hashing .. p-fish')

    parser.add_argument('-v','--verbose', help = 'allows progress messages to be displayed',
     action = 'store_true')
    # setup a group where the selection is mutually exclusive and required.

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--md5', help='specifies MD5 algorithm', action ='store_true')
    group.add_argument('--sha256', help = 'specifies SHA256 algorithm', action ='store_true')
    group.add_argument('--sha512', help ='specifies SHA512 algorithm', action ='store_true')

    #Get the correct hashing algorithem name 
    group.add_argument('--sha224', help = 'specifies SHA233 algoritm', action = 'store_true')
    group.add_argument('--sha384', help = 'specifies SHA233 algoritm', action = 'store_true')

    parser.add_argument('-d','--rootPath', type = ValidateDirectory, required=True,
     help="specify the root path for hashing")
    parser.add_argument('-r','--reportPath', type = ValidateDirectoryWritable, required=True,
     help="specify the path for reports and logs will be written")

    #create a global object to hold the validated arguments, these will be available then
    #to all the Functions within the _pfish.py module
 
    #global gl_args
    #global gl_hashType


    args = parser.parse_args()
    hashType = parser.parse_args()

    #change this back to gl_arg if need be. 

    if args.md5:
        hashType = 'MD5'
    
    elif args.sha256:
        hashType = 'SHA256'

    elif args.sha512:
        hashType = 'SHA512'

    elif args.sha224:
       hashType = 'SHA224'

    elif args.sha384:  
       hashType = 'SHA384'

    else:
        hashType = "Unknown"
        logging.error('Unknown Hash Type Specified')
        DisplayMessage("Command line processed: Successfully")
        return

    return args 

    #End ParseCommandLine =========================================================

def WalkPath():
    processCount = 0
    errorCount = 0

    hashType = ParseCommandLine()

    oCVS = CSVWriter(ParseCommandLine().reportPath+ 'fileSystemReport.csv', hashType)

    #this has been added
   # hashCVS = CSVWriter(gl_args.reportPath + 'Contrabandhashes.csv', gl_hashType)

    #Create a loop that process all the files starting # at the rootPath, all sub-directories will also be # processed
    log.info('Root Path:' + ParseCommandLine().rootPath)

    #prints the hash function used to the log file.

    if hashType.md5 == True:
        log.info('Hash function used is: MD5')

    elif hashType.sha256 == True:
        log.info('Hash function used is: SHA-256')
    
    elif hashType.sha512 == True:
        log.info('Hash function used is: SHA-512')

    elif hashType.sha224 == True:
        log.info('Hash function used is: SHA-224')

    elif hashType.sha384 == True:
        log.info('Hash function used is: SHA-384')

    #Program wouldnt even run a unknwon hashfunction is used. 
    else: 
        log.info("unkwnown hash function used, Try again")

    

    for root, dirs, files in os.walk(ParseCommandLine().rootPath):

        #for each file obtain the filename and call the HashFile Function
        for file in files:
            fname = os.path.join(root, file)
            result = HashFile(fname, file, oCVS)

        # this has been added 
    

    #if hashing was successful then increment the ProcessCount
    if result is True:
        processCount += 1

    #if not successful, the increment the ErrorCount
    else:
        ErrorCount += 1
        oCVS.writerClose()
        return(processCount)

#End WalkPath==========================================

def HashFile(theFile, simpleName, o_result):

    if os.path.exists(theFile):

        #Verify that the path is not a symbolic link
        if not os.path.islink(theFile):

            #Verify that the file is real
            if os.path.isfile(theFile):
                try:
                    #Attempt to open the file
                    f = open(theFile,'rb')
                except IOError:

                    #if open fails report the error
                    log.warning('Open Failed:'+ theFile)
                    return
                else:
                    try:
                        rd = f.read()
                    except IOError:
                        # if read fails, then close the file and report error
                        f.close()
                        log.warning('Read Failed:'+ theFile)
                        return

                    else:
                        #success the file is open and we can read from it #lets query the file stats
                        theFileStats = os.stat(theFile)
                        (mode, ino, dev, nlink, uid, gid, size, atime, mtime, ctime) = os.stat(theFile)

                        #Print the simple file name
                        DisplayMessage("Processing File: " + theFile)

                        # print the size of the file in Bytes
                        fileSize = str(size)

                        #print MAC Times
                        modifiedTime = time.ctime(mtime)
                        accessTime = time.ctime(atime)
                        createdTime = time.ctime(ctime)
                        ownerID = str(uid)
                        groupID = str(gid)
                        fileMode = bin(mode)
                        #process the file hashes

                        #changed gl_args to args 

                        if ParseCommandLine().md5:
                            #Calcuation and Print the MD5
                            hash = hashlib.md5()
                            hash.update(rd)
                            hexMD5 = hash.hexdigest()
                            hashValue = hexMD5.upper()

                        elif ParseCommandLine().sha256:
                            hash= hashlib.sha256()
                            hash.update(rd)
                            hexSHA256 = hash.hexdigest()
                            hashValue = hexSHA256.upper()

                        elif ParseCommandLine().sha512:
                            #Calculate and Print the SHA512
                            hash = hashlib.sha512()
                            hash.update(rd)
                            hexSHA512 = hash.hexdigest()
                            hashValue = hexSHA512.upper()
                        

                        #addidtional if statements have been added for diffent hash fuctions. 

                        elif ParseCommandLine().sha224:
                            #calculate and print the SHA224
                            hash = hashlib.sha224()
                            hash.update(rd)
                            hexSHA224 = hash.hexdigest()
                            hashValue = hexSHA224.upper()

                        elif ParseCommandLine().sha384:
                            #calculate and print the SHA384
                            hash = hashlib.sha384()
                            hash.update(rd)
                            hexSHA384 = hash.hexdigest()
                            hashValue = hexSHA384.upper()


                        else:
                            log.error('Hash not Selected')

                    #File processing completed
                    #Close the Active File

                    print "Processing files: " + str(theFile)
                
                    f.close()
                    #write one row to the output file
                    o_result.writeCSVRow(simpleName, theFile, fileSize, modifiedTime,
                     accessTime, createdTime, hashValue, ownerID, groupID, mode)
                    return True

            else:
                log.warning('['+ repr(simpleName) +', Skipped NOT a File' + ']')
                return False
        else:
            log.warning('['+ repr(simpleName) +', Skipped Link NOT a File' + ']')
            return False
    else:
        log.warning('['+ repr(simpleName) +', Path does NOT exist' + ']')
        return false

#End HashFile Function =================================

def ValidateDirectory(theDir):

    #Validate the path is a directory
    if not os.path.isdir(theDir):
        raise argparse.ArgumentTypeError('Directory does not exist')

    #Validate the path is readable
    if os.access(theDir, os.R_OK):
        return theDir

    else:
        raise argparse.ArgumentTypeError('Directory is not readable')

#End ValidateDirectory ==================================

def ValidateDirectoryWritable(theDir):
    #Validate the path is a directory
    if not os.path.isdir(theDir):
        raise argparse.ArgumentTypeError('Directory does not exist')

    #Validate the path is writable
    if os.access(theDir, os.W_OK):

        return theDir

    else:
        raise argparse.ArgumentTypeError('Directory is not writable')


#End ValidateDirectoryWritable ============================

def DisplayMessage(msg):

    if ParseCommandLine().verbose:
        print(msg)

    

#End DisplayMessage=====================================

class CSVWriter:

    def __init__(self, fileName, hashType):
        try:
        #create a writer object and then write the header row

            self.csvFile = open(fileName,'wb')
            self.writer = csv.writer(self.csvFile, delimiter = ',', quoting= csv.QUOTE_ALL)
            self.writer.writerow( ('File','Path','Size','Modified Time', 'Access Time',
            'Created Time', 'hashType' ,'Owner','Group','Mode') )
        except:
            log.error('CSV File Failure')

        #this has been added 

        # end of what has been added 
    def writeCSVRow(self, fileName, filePath, fileSize, mTime,
             aTime, cTime, hashVal, own, grp, mod):

            self.writer.writerow( (fileName, filePath, fileSize, mTime,
             aTime, cTime, hashVal, own, grp, mod))

    def writerClose(self):
        self.csvFile.close()
