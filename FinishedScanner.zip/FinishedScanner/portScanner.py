import wx
import pyping 
import sys 
from socket import * 

from time import gmtime, strftime 



def portScan(event): 

    if portEnd.GetValue() < portStart.GetValue():

        dlg = wx.MessageDialog(mainWin, "Invalid Host Port Selection", "Confirm",
         wx.OK | wx.ICON_EXLAMATION)

        result = dlg.ShowModal()
        dlg.Destroy()
        return 


    mainWin.StatusBar.SetStatusText('Executing Port Scan.... Please Wait')

    # record start time 


    utcStart = gmtime() 
    utc = strftime("%a, %d %Y %X", utcStart)
    results.AppendText('\n\n Port Scan Started: ' + utc + '\n\n')


    baseIP = str(ipaRange.GetValue()) + '.'+str(ipbRange.GetValue()) + '.'+ str(ipcRange.GetValue())+'.'+str(ipdRange.GetValue())


    # start with the for loop on page 230     

    for port in range(portStart.GetValue(), portEnd.GetValue() + 1):
    
        try: 

            mainWin.StatusBar.SetStatusText('Scanning: ' + baseIP + ' Port: ' + str(port))

            #open socket 
            reqSocket = socket(AF_INET, SOCK_STREAM)

            #try connecting to the specified ip, port 
            reqSocket.settimeout(5)

            response = reqSocket.connect_ex((baseIP, port))

            if(response == 0):
                #display the ipAddress and port 
                results.AppendText(baseIP+'\t'+str(port)+ '\t')
                results.AppendText('Open')
                results.AppendText('\n')

            else: 

                if displayAll.GetValue() == True: 
                    results.AppendText(baseIP+'\t'+str(port)+ '\t')
                    results.AppendText('Closed')
                    results.AppendText('\n')

            reqSocket.close()

        except socket.error, e:

            results.AppendText(baseIP+'\t'+str(port)+ '\t')
            results.AppendText('Failed')
            results.AppendText(e.message)
            results.AppendText('\n')



    utcEnd = gmtime()
    utc = strftime("%a, %d %Y %X", utcEnd)
    results.AppendText('\n\n Port Scan Ended: ' + utc + '\n\n')


    mainWin.StatusBar.SetStatusText('')


    #end event handler ========================================


def programExit(event):

    sys.exit() 


# end program exit event handler 


#set up Application windows 

app = wx.App()

#define window 

mainWin = wx.Frame(None, title='Port scanner', size = (1200, 600))

#define action pannel 

panelAction = wx.Panel(mainWin)


#define action buttons 


#next steps are create displayALL on page 231

displayAll = wx.CheckBox(panelAction, -1, 'Dispaly All', (10,10))
displayAll.SetValue(True)


scanButton = wx.Button(panelAction, label='Scan')
scanButton.Bind(wx.EVT_BUTTON, portScan)

exitButton = wx.Button(panelAction, label='Exit')
exitButton.Bind(wx.EVT_BUTTON, programExit)


#define a Text Area wehre I can display results 

results = wx.TextCtrl(panelAction, style = wx.TE_MULTILINE | wx.HSCROLL)

#Base network to class C IP address has 3 compnents 


#Class A

ipaRange = wx.SpinCtrl(panelAction, -1,'') 
ipaRange.SetRange(0, 255) 
ipaRange.SetValue(127)


#Class B

ipbRange = wx.SpinCtrl(panelAction, -1,'')
ipbRange.SetRange(0, 255) 
ipbRange.SetValue(0)

# Clas C

ipcRange = wx.SpinCtrl(panelAction, -1,'') 
ipcRange.SetRange(0, 255) 
ipcRange.SetValue(0)

# Class D

ipdRange = wx.SpinCtrl(panelAction, -1,'') 
ipdRange.SetRange(0, 255)
ipdRange.SetValue(1)

ipLabel = wx.StaticText(panelAction, label= 'IP Address: ')


portStart = wx.SpinCtrl(panelAction, -1, '')
portStart.SetRange(1,49800)
portStart.SetValue(5)

portEnd = wx.SpinCtrl(panelAction, -1, '')
portEnd.SetRange(1, 49810)
portEnd.SetValue(5)

PortStartLabel = wx.StaticText(panelAction, label = 'Port Start: ')
PortEndLabel = wx.StaticText(panelAction, label = 'Port End: ')

# first, I created a horizontal Box 

actionBox = wx.BoxSizer()

actionBox.Add(displayAll, proportion = 0, flag=wx.LEFT|wx.CENTER, border=5)
actionBox.Add(scanButton, proportion=0, flag=wx.LEFT,border=5)
actionBox.Add(exitButton, proportion=0, flag=wx.LEFT,border=5)

actionBox.Add(ipLabel, proportion = 0, flag=wx.LEFT|wx.CENTER, border=5)

actionBox.Add(ipaRange, proportion=0, flag=wx.LEFT,border=5)
actionBox.Add(ipbRange, proportion=0, flag=wx.LEFT,border=5)
actionBox.Add(ipcRange, proportion=0, flag=wx.LEFT,border=5)
actionBox.Add(ipdRange, proportion=0, flag=wx.LEFT,border=5)

# port start

actionBox.Add(PortStartLabel, proportion = 0, flag=wx.LEFT|wx.CENTER, border=5)
actionBox.Add(portStart, proportion=0, flag=wx.LEFT,border=5)

#portEnd

actionBox.Add(PortEndLabel, proportion = 0, flag=wx.LEFT|wx.CENTER, border=5)
actionBox.Add(portEnd, proportion=0, flag=wx.LEFT,border=5)

#Creating the vertical Box 

vertBox = wx.BoxSizer(wx.VERTICAL)
vertBox.Add(actionBox, proportion=0, flag=wx.EXPAND|wx.ALL, border = 5)
vertBox.Add(results, proportion=1, flag=wx.EXPAND | wx.LEFT | wx.BOTTOM | wx.RIGHT, border =5)

# im adding a menu and status bar to the main window 

mainWin.CreateStatusBar()

panelAction.SetSizer(vertBox)

mainWin.Show()



app.MainLoop()

