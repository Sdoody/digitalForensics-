#!/usr/bin/python2.7 

#192.168.0.-

import wx 
import pyping
import sys 
import socket
import random
import time
import threading

from time import gmtime,strftime 


# listener functions 
def pingScan(event): 
    #resultPane.AppendText("Scan button clicked!\n")
    if hostEnd.GetValue() < hostStart.GetValue():

        #this is a nimproper setting 
        #notify yhe user usign a wx.MessageDialog Box 

        dlg = wx.MessageDialog(mainWin,"Invalid Local Host Selection",
         "Confirm", wx.OK | wx.ICON_EXCLAMATION)
        
        result = dlg.ShowModal()
        dlg.Destroy()
        return 

    mainWin.StatusBar.SetStatusText('Executing Ping Sweep....Please Wait')

    # record the start time and update the result window 

    utcStart = gmtime()
    utc = strftime("%a, %d %b %Y %X", utcStart)
    results.AppendText('\nPing Sweep Started: ' + utc + '\n\n')
 
    baseIP = str(ipaRange.GetValue()) + '.' + str(ipbRange.GetValue()) + '.' + str(ipcRange.GetValue()) + '.'

   #print baseIP

    ipRange = []

    for i in range(hostStart.GetValue(), (hostEnd.GetValue()+1)): 
        ipRange.append(baseIP+str(i))

    # for each of the Ip addresses in the ipRange list, attempt an PING 
    
    for ipAddress in ipRange:
        try: 
            # report the IP Address to the window status bar 

            mainWin.StatusBar.SetStatusText('Pinging IP:' + ipAddress)
            #this needs to be adjusted to pyping not ping. 
            delay = pyping.ping(ipAddress)
            #cprint delay.ret_code
           
            totalTime = delay.avg_rtt
            print totalTime

            box = stealthMode.GetValue()


            if box: 
                #print "running settings if statement."
                randomSleep = random.randint(2,10)
                sleeptime = time.sleep(randomSleep)
                results.AppendText("Sleeping for " + str(randomSleep) + " Seconds")
                results.AppendText('\n')
            
            #display the IP address in the MAIN window 
            results.AppendText(ipAddress+'\t')

            if delay.ret_code == 0: 
                
                results.AppendText('Response Success, ')
                results.AppendText("Response Time: " + str(totalTime)+ ' Seconds')
                results.AppendText('\n')


            else: 
                
                results.AppendText('Response Timeout')
                results.AppendText('\n')

        except socket.error, e: 

            results.AppendText(ipAddress)
            results.AppendText('Response Failed:')
            results.AppendText(e.message)
            results.AppendText('\n')

    
    utcEnd = gmtime()
    utc = strftime("%a, %d %b %Y %X", utcEnd)
    results.AppendText('\n\nPing Sweep Ended: ' + utc + '\n\n')


    #Clear the status Bar 
    mainWin.StatusBar.SetStatusText('')

    return 

# end Scan EVent Handler. 

    #Similar to the example script at the begininngin of the chapter 
    # I need to build the base IP address String 
    #Extract data from the ip Range and jpst name user selection 
    #Build a python list of IP addressed to sweep 


    # next step is on page 220
        

def programExit(event): 
    #resultPane.AppendText("Exit button clicked\n")
    exit()


#def stealthCheck(event):
    #print "boxed is checked"
   

# 1. create the application object and window 

app = wx.App()
mainWin = wx.Frame(None, title= "Ping", size = (1200,800))

# 2. Create the overall panel.

actionsPanel = wx.Panel(mainWin)

# 3. put two buttons in panel

stealthMode = wx.CheckBox(actionsPanel, -1, 'Stealth Mode', (1,1))
stealthMode.SetValue(False)
scanButton = wx.Button(actionsPanel, label='Scan')
exitButton = wx.Button(actionsPanel, label='Exit')


#Binds the buttons to the listener Function 
scanButton.Bind(wx.EVT_BUTTON, pingScan)
exitButton.Bind(wx.EVT_BUTTON, programExit)
#stealthMode.Bind(wx.EVT_CHECKBOX, stealthCheck)

#create another pane for the text box 

results = wx.TextCtrl(actionsPanel, style=wx.TE_MULTILINE | wx.HSCROLL)


ipaRange = wx.SpinCtrl(actionsPanel, -1, '')
ipaRange.SetRange(0,255)
ipaRange.SetValue(127)

ipbRange = wx.SpinCtrl(actionsPanel, -1, '')
ipbRange.SetRange(0,255)
ipbRange.SetValue(0)

ipcRange = wx.SpinCtrl(actionsPanel, -1, '')
ipcRange.SetRange(0,255)
ipcRange.SetValue(0)

ipLabel = wx.StaticText(actionsPanel, label="IP base: ")

# Next, I want to provide to user wtih ability to set the host range
# they wish to scan Range is 0-255

hostStart = wx.SpinCtrl(actionsPanel, -1, '')
hostStart.SetRange(0,255)
hostStart.SetValue(1)

hostEnd = wx.SpinCtrl(actionsPanel, -1, '')
hostEnd.SetRange(0,255)
hostEnd.SetValue(2)

hostStartLabel = wx.StaticText(actionsPanel, label = "Host Start: ")
hostEndLabel = wx.StaticText(actionsPanel, label = 'Host End: ')

# 4. Create a sizer object and add buttons to that 

actionsBox = wx.BoxSizer()
actionsBox.Add(scanButton, proportion=1, flag=wx.LEFT, border=5)
actionsBox.Add(exitButton, proportion=1, flag=wx.LEFT, border=5)
actionsBox.Add(stealthMode, proportion=1, flag=wx.LEFT, border=5)
# make actions box the sizer for actionsPanel 

actionsBox.Add(ipLabel, proportion = 0, flag =wx.LEFT, border = 5)

actionsBox.Add(ipaRange, proportion = 0, flag =wx.LEFT, border = 5)
actionsBox.Add(ipbRange, proportion = 0, flag =wx.LEFT, border = 5)
actionsBox.Add(ipcRange, proportion = 0, flag =wx.RIGHT, border = 5)

actionsBox.Add(hostStartLabel, proportion = 0, flag = wx.LEFT|wx.CENTER, border = 5)
actionsBox.Add(hostStart, proportion = 0, flag = wx.LEFT, border = 5)

actionsBox.Add(hostEndLabel, proportion = 0, flag = wx.LEFT|wx.CENTER, border = 5)
actionsBox.Add(hostEnd, proportion = 0, flag=wx.LEFT, border = 5)

actionsBox.Add

#actionsPanel.SetSizer(actionsBox)

# 5. create a vertical sizer fro the whole window 

vertBox = wx.BoxSizer(wx.VERTICAL)
vertBox.Add(actionsBox, proportion=0, flag=wx.EXPAND | wx.ALL, border=5)
vertBox.Add(results, proportion=1, flag=wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM , border=5)

# 6. assocatate the vertcalBox  witht he vertical pane 

actionsPanel.SetSizer(vertBox)


mainWin.CreateStatusBar() 

#mainWin.CreateToolBar()


# show the frame and start the main loop 

mainWin.Show()
app.MainLoop()

